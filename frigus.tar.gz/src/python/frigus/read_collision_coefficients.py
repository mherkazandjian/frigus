# -*- coding: utf-8 -*-
"""
Read the collisional rates (collision coefficients)
"""
from StringIO import StringIO
import numpy
from numpy import (loadtxt, arange, int32, zeros, unique, void,
                   ascontiguousarray, dtype, hstack, fabs, exp)

from astropy import units as u


def unique_level_pairs(vj):
    """from a list of levels find the list of unique levels and return them.
    :param iterable vj: the list of v levels where each item vj[x] is a level.
    The shape of vj should be (2,n) where n is the number of levels.
    :return: (ndarray) The unique levels. The shape of this array is
    (2,n_unique) where n_unique is the number of unique transitions.

    .. code-block: python

        vj = array([[0, 0, 0, 7, 4, 8, 4, 6, 9, 8, 9, 6, 2, 0, 5, 5, 9, 8, 1],
                    [4, 4, 3, 5, 3, 6, 3, 8, 2, 5, 7, 8, 8, 6, 6, 9, 1, 0, 9]])
        vj_unique = unique_level_pairs(vj)
    """

    assert vj.shape[0] == 2

    a = vj.T
    new_dtype = dtype((void, a.dtype.itemsize * 2))
    b = ascontiguousarray(a).view(new_dtype)
    _, idx = unique(b, return_index=True)
    unique_a = a[idx]
    return unique_a.T


def read_collision_coefficients_lipovka(fname):
    """
    Parse the collisional data used by lipovka. These are the coefficient
    rates K_ij where i > j (so these fill the lower triangular K matrix).

    The table contains the HD-H collisional rate coefficients

    v, v' : initial and final vibrational state
    j, j' : initial and final rotational state

    the data are stored in blocks for each temperature. The colomns are the
    initial ro-vibrational (v,j) level and the rows are the final ones (v', j')
    http://massey.dur.ac.uk/drf/HD_H/

    :param string fname: The path to the ascii data.
    :return: a tuple of 3 elements.
      The first element is a 5D array that holds all the rate coefficients.
      K[T_index, v, j, v', j'] ( in m3/s)

      The second element is a 1D temperature array (T) corresponding to the
      rate coefficients in the 5D array. This array has the same size as the
      last dimension of K (i.e K[:,0,0,0,0].size = T.size

      The third element is a tuple of 4 elements:

         - The first element is a 2D array of shape (2, n_transitions) (ini).
           The columns of this array (v, j = ini) are the initial v and j of
           the transitions for a certain T section. i.e. the number of non-zero
           elements in K for a certain temperature is equal to the number of
           elements in the v or j columns. It is assumed that 'ini' are the 
           same for each temperature value. 
           v.size = j.size = where(K[..., 0] > 0)[0].size

         - The second element is the same of the first element but for the
           final transitions (v', j' = fin)

         - The third element is a 2D array of shape (2, n_unique_transitions)
           that are the unique levels involved in all the transitions.

         - The last element is an array of shape (T.size, n_transitions)
           which are the collisional coefficient rates with non-zero values
           for each value of temperature in the T array. Each row corresponds
           to the ini, fin collision rates of the first and second element
           in the tuple mentioned earlier.
    """

    class Reader(object):
        """parse the  data by Flower and Roueff contained in the file
           flower_roueff_data.dat downloaded from http://massey.dur.ac.uk/drf/HD_H

           A block of data (for a certain temperature) is defined as everything
           between:

           100
           (0,0) (0,1) (0,2) (0,3) (0,4) (0,5) (0,6) (0,7) (0,8) (0, 9)
           1.0D-09 1.5D-11 5.4D-13 4.0D-14 7.8D-15 6.1D-16 2.4D-17 8.7D-18 2.2D-18 2.3D-19
           ...
           ...

        .. code-block:: python

            reader = read_cr_lipovka.Reader('path_to_the_file')

            # print all the collision rates for the transition (v,j) -> (vp,jp)
            # for
            # all the temperatures
            print reader.data[v, j, vp, jp, :]
        """
        def __init__(self, fname, tiny=1e-70):
            """constructor"""

            self.fname = fname
            self.data = None  #: the collision rates for all the transitions for all the tempratures
            self.ini = None  #: the initial v,j of all the transitions
            self.fin = None  #: the final v,j of all the transitions
            self.tkin = None  #: the temperatures at which the collisional data are given

            self.read_data()

        def read_data(self):
            """read all the data to temporary storage in self.data"""

            with open(self.fname) as fobj:
                linesold = fobj.readlines()
                lines = []
                for line_no, line in enumerate(linesold):
                    if line.isspace() is False and line_no >= 12:
                        lines.append(line)
                raw_data = ''.join(lines)

            cr, ini, fin, tkin = self.parse_data(raw_data)
            self.data = cr
            self.ini = ini
            self.fin = fin
            self.tkin = tkin

        def parse_data(self, raw_data):
            """
            Parses the read data into blocks, one block for each temperature
            """

            # split the raw data into blocks
            blocks = raw_data.split('T =')[1:]

            tkin = zeros(len(blocks), 'f8')
            cr_tkin = []
            ini_tkin = []
            fin_tkin = []

            for ib, block in enumerate(blocks):
                ini, fin, t, cr = self.parse_block(block)
                tkin[ib] = t
                cr_tkin.append(cr)
                ini_tkin.append(ini)
                fin_tkin.append(fin)

            return cr_tkin, ini_tkin, fin_tkin, tkin

        def parse_block(self, block):
            """parse a block of data and return the temperature, the levels
            and the collision rates"""
            lines = iter(filter(lambda x: len(x) > 0, block.split('\n')))

            # get the temperature
            T = lines.next()
            assert 'K' in T
            tkin = T.replace('K', '')
            # print T, tkin

            # get the header (levels)
            levels = lines.next().replace(' ', '').replace(')(', ':')[
                     1:-1].split(':')
            v, j = [], []
            for level in levels:
                v.append(int32(level.split(',')[0]))
                j.append(int32(level.split(',')[1]))
            v, j = numpy.array(v), numpy.array(j)

            ini = numpy.repeat(numpy.vstack((v, j)), len(v), axis=1)
            fin = numpy.tile([v, j], len(v))

            cr = zeros((v.size, j.size, v.size, j.size), 'f8')
            for final_state_ind, line in enumerate(lines):
                vp, jp = v[final_state_ind], j[final_state_ind]
                if len(line.strip()) > 0:
                    data = numpy.float64(line.replace('D', 'E').strip().split())
                    for initial_state_ind, datum in enumerate(data):
                        vi, ji = v[initial_state_ind], j[initial_state_ind]
                        cr[vi, ji, vp, jp] = datum

            return ini, fin, tkin, cr

    reader = Reader(fname)

    T_values = reader.tkin

    # read the data from the original ascii file
    # data_read = loadtxt(fname, unpack=True, skiprows=10)
    # (v, j, vp, jp), cr = int32(data_read[0:4]), data_read[4:]

    ini = reader.ini[0]
    fin = reader.fin[0]

    v, j = ini[0, :], ini[1, :]
    vp, jp = fin[0, :], fin[1, :]

    n_transitions_per_T_value = v.size

    # declare the array where the data will be stored in a tensor
    nv, nj, nvp, njp = v.max()+1, j.max()+1, vp.max()+1, jp.max()+1
    nv_max, nj_max = max(nv, nvp), max(nj, njp)
    data = zeros((T_values.size, nv_max, nj_max, nv_max, nj_max), 'f8')

    # declare the array where the data will be stored in a matrix
    cr = numpy.zeros((T_values.size, n_transitions_per_T_value), 'f8')

    # copy the read data into the container array
    for i, cri in enumerate(reader.data):
        data[i, v, j, vp, jp] = cri[v, j, vp, jp]
        cr[i, :] = cri[v, j, vp, jp]

    # find the unique levels from from the transitions
    unique_levels = unique_level_pairs(hstack((unique_level_pairs(ini),
                                               unique_level_pairs(fin))))

    # set the units of the data to be returned
    data_with_units = data * (u.cm**3 / u.second)
    cr_with_units = cr * (u.cm**3 / u.second)
    T_values = T_values * u.K

    # convert the units to m^3/s
    data_with_units = data_with_units.to(u.m**3 / u.second)
    cr_with_units = cr_with_units.to(u.m**3 / u.second)

    return data_with_units, T_values, (ini, fin, unique_levels, cr_with_units)
